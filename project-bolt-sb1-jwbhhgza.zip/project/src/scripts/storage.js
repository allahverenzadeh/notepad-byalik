/**
 * Handles localStorage operations for the Notepad application
 */
const Storage = {
  // Key constants
  NOTES_KEY: 'notepad_notes',
  ACTIVE_NOTE_KEY: 'notepad_active_note',
  THEME_KEY: 'notepad_theme',
  SETTINGS_KEY: 'notepad_settings',
  
  /**
   * Save a note to localStorage
   * @param {Object} note - The note object to save
   */
  saveNote: (note) => {
    // Get all existing notes
    const notes = Storage.getAllNotes();
    
    // Update the note if it exists, otherwise add it
    const index = notes.findIndex(n => n.id === note.id);
    if (index !== -1) {
      notes[index] = note;
    } else {
      notes.push(note);
    }
    
    // Save back to localStorage
    localStorage.setItem(Storage.NOTES_KEY, JSON.stringify(notes));
    
    // Update active note
    Storage.setActiveNoteId(note.id);
  },
  
  /**
   * Get all notes from localStorage
   * @returns {Array} Array of note objects
   */
  getAllNotes: () => {
    const notesStr = localStorage.getItem(Storage.NOTES_KEY);
    return notesStr ? JSON.parse(notesStr) : [];
  },
  
  /**
   * Get a specific note by ID
   * @param {string} id - The note ID
   * @returns {Object|null} The note object or null if not found
   */
  getNoteById: (id) => {
    const notes = Storage.getAllNotes();
    return notes.find(note => note.id === id) || null;
  },
  
  /**
   * Delete a note by ID
   * @param {string} id - The note ID to delete
   * @returns {boolean} True if the note was deleted, false otherwise
   */
  deleteNote: (id) => {
    const notes = Storage.getAllNotes();
    const initialLength = notes.length;
    const filteredNotes = notes.filter(note => note.id !== id);
    
    localStorage.setItem(Storage.NOTES_KEY, JSON.stringify(filteredNotes));
    
    // If the active note was deleted, update it
    if (Storage.getActiveNoteId() === id) {
      if (filteredNotes.length > 0) {
        Storage.setActiveNoteId(filteredNotes[0].id);
      } else {
        localStorage.removeItem(Storage.ACTIVE_NOTE_KEY);
      }
    }
    
    return filteredNotes.length < initialLength;
  },
  
  /**
   * Save the active note ID
   * @param {string} id - The active note ID
   */
  setActiveNoteId: (id) => {
    localStorage.setItem(Storage.ACTIVE_NOTE_KEY, id);
  },
  
  /**
   * Get the active note ID
   * @returns {string|null} The active note ID or null
   */
  getActiveNoteId: () => {
    return localStorage.getItem(Storage.ACTIVE_NOTE_KEY);
  },
  
  /**
   * Save the current theme
   * @param {string} theme - The theme name ('light' or 'dark')
   */
  saveTheme: (theme) => {
    localStorage.setItem(Storage.THEME_KEY, theme);
  },
  
  /**
   * Get the saved theme
   * @returns {string} The saved theme or default based on system preference
   */
  getTheme: () => {
    const savedTheme = localStorage.getItem(Storage.THEME_KEY);
    if (savedTheme) return savedTheme;
    
    // If no saved theme, use system preference
    return Utils.prefersDarkMode() ? 'dark' : 'light';
  },
  
  /**
   * Save application settings
   * @param {Object} settings - The settings object
   */
  saveSettings: (settings) => {
    localStorage.setItem(Storage.SETTINGS_KEY, JSON.stringify(settings));
  },
  
  /**
   * Get application settings
   * @returns {Object} The settings object
   */
  getSettings: () => {
    const settingsStr = localStorage.getItem(Storage.SETTINGS_KEY);
    const defaultSettings = {
      fontFamily: "'Inter', sans-serif",
      fontSize: '16px',
      fontColor: '#333333',
      autoSave: 10 // seconds
    };
    
    if (!settingsStr) return defaultSettings;
    
    try {
      return { ...defaultSettings, ...JSON.parse(settingsStr) };
    } catch (e) {
      console.error('Error parsing settings:', e);
      return defaultSettings;
    }
  }
};