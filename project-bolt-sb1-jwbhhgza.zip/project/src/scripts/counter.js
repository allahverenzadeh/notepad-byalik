/**
 * Handles character and word counting
 */
const Counter = {
  charCountEl: null,
  wordCountEl: null,
  
  /**
   * Initialize the counter
   */
  init: () => {
    Counter.charCountEl = document.getElementById('charCount');
    Counter.wordCountEl = document.getElementById('wordCount');
    
    // Initial count update
    Counter.updateCounts();
  },
  
  /**
   * Update character and word counts
   */
  updateCounts: () => {
    const text = document.getElementById('editor').value;
    
    // Character count (including spaces)
    const charCount = text.length;
    
    // Word count (split by whitespace and filter out empty strings)
    const wordCount = text
      ? text.trim().split(/\s+/).filter(word => word.length > 0).length
      : 0;
    
    // Update the UI
    Counter.charCountEl.textContent = charCount;
    Counter.wordCountEl.textContent = wordCount;
  },
  
  /**
   * Get the current character count
   * @returns {number} Character count
   */
  getCharCount: () => {
    return parseInt(Counter.charCountEl.textContent);
  },
  
  /**
   * Get the current word count
   * @returns {number} Word count
   */
  getWordCount: () => {
    return parseInt(Counter.wordCountEl.textContent);
  }
};