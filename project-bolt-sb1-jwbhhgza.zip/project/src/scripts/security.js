/**
 * Handles password protection functionality
 */
const Security = {
  passwordModal: null,
  passwordInput: null,
  passwordPrompt: null,
  
  /**
   * Initialize security features
   */
  init: () => {
    // Get DOM elements
    Security.passwordModal = document.getElementById('passwordModal');
    Security.passwordInput = document.getElementById('passwordInput');
    Security.passwordPrompt = document.getElementById('passwordPrompt');
    
    // Set up event listeners
    document.getElementById('lockNote').addEventListener('click', Security.toggleLock);
    document.getElementById('confirmPassword').addEventListener('click', Security.confirmPassword);
    document.getElementById('cancelPassword').addEventListener('click', () => {
      UI.closeModal('passwordModal');
    });
    
    // Close modal when clicking the X button
    document.querySelector('#passwordModal .close-modal').addEventListener('click', () => {
      UI.closeModal('passwordModal');
    });
    
    // Handle Enter key in password field
    Security.passwordInput.addEventListener('keyup', (e) => {
      if (e.key === 'Enter') {
        document.getElementById('confirmPassword').click();
      }
    });
  },
  
  /**
   * Toggle lock status for the current note
   */
  toggleLock: () => {
    const currentNote = Editor.getCurrentNote();
    if (!currentNote) return;
    
    if (currentNote.isProtected) {
      // If currently protected, verify password before unlocking
      Security.passwordPrompt.textContent = 'Enter the current password to unlock this note:';
      Security.passwordInput.value = '';
      
      Security.showPasswordModal((password) => {
        // Verify the password
        if (password === currentNote.password) {
          // Password correct, unlock the note
          delete currentNote.password;
          currentNote.isProtected = false;
          
          // Save the changes
          Storage.saveNote(currentNote);
          Notes.populateNotesList();
          
          Utils.showToast('Note unlocked');
        } else {
          // Incorrect password
          Utils.showToast('Incorrect password', 3000);
        }
      });
    } else {
      // Not protected, set a password
      Security.passwordPrompt.textContent = 'Set a password to protect this note:';
      Security.passwordInput.value = '';
      
      Security.showPasswordModal((password) => {
        if (password && password.trim() !== '') {
          // Set the password and mark as protected
          currentNote.password = password;
          currentNote.isProtected = true;
          
          // Save the changes
          Storage.saveNote(currentNote);
          Notes.populateNotesList();
          
          Utils.showToast('Note locked with password');
        }
      });
    }
  },
  
  /**
   * Show the password modal dialog
   * @param {Function} callback - Function to call with the entered password
   */
  showPasswordModal: (callback) => {
    Security.currentCallback = callback;
    UI.openModal('passwordModal');
    Security.passwordInput.focus();
  },
  
  /**
   * Handle password confirmation button click
   */
  confirmPassword: () => {
    const password = Security.passwordInput.value;
    UI.closeModal('passwordModal');
    
    if (Security.currentCallback) {
      Security.currentCallback(password);
      Security.currentCallback = null;
    }
  },
  
  /**
   * Prompt for password when accessing a protected note
   * @param {Object} note - The protected note
   * @param {Function} callback - Function to call with success/failure
   */
  promptForPassword: (note, callback) => {
    if (!note.isProtected || !note.password) {
      callback(true);
      return;
    }
    
    Security.passwordPrompt.textContent = 'This note is password protected. Enter the password:';
    Security.passwordInput.value = '';
    
    Security.showPasswordModal((password) => {
      const success = password === note.password;
      
      if (!success) {
        Utils.showToast('Incorrect password', 3000);
      }
      
      callback(success);
    });
  }
};