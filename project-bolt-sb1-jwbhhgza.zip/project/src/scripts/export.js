/**
 * Handles export functionality
 */
const Export = {
  /**
   * Initialize export features
   */
  init: () => {
    // Set up event listeners
    document.getElementById('downloadButton').addEventListener('click', Export.downloadAsTxt);
    document.getElementById('emailButton').addEventListener('click', Export.sendViaEmail);
  },
  
  /**
   * Download the current note as a .txt file
   */
  downloadAsTxt: () => {
    const currentNote = Editor.getCurrentNote();
    if (!currentNote) return;
    
    // Get the content and title
    const content = currentNote.content;
    let filename = (currentNote.title || 'Untitled').replace(/[^a-z0-9]/gi, '_').toLowerCase();
    
    // Create a blob with the content
    const blob = new Blob([content], { type: 'text/plain;charset=utf-8' });
    
    // Create a temporary link element
    const link = document.createElement('a');
    link.href = URL.createObjectURL(blob);
    link.download = `${filename}.txt`;
    
    // Append to the document, click, and remove
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
    
    // Clean up the URL object
    setTimeout(() => {
      URL.revokeObjectURL(link.href);
    }, 100);
    
    Utils.showToast('Note downloaded as TXT file');
  },
  
  /**
   * Send the current note via email
   */
  sendViaEmail: () => {
    const currentNote = Editor.getCurrentNote();
    if (!currentNote) return;
    
    // Get the content and title
    const title = currentNote.title || 'Untitled Note';
    const content = currentNote.content;
    
    // Create the mailto URL
    const subject = encodeURIComponent(title);
    const body = encodeURIComponent(content);
    const mailtoUrl = `mailto:?subject=${subject}&body=${body}`;
    
    // Open the mailto URL
    window.location.href = mailtoUrl;
  }
};