/**
 * Utility functions for the Notepad application
 */
const Utils = {
  /**
   * Generate a unique ID
   * @returns {string} A unique ID string
   */
  generateId: () => {
    return Date.now().toString(36) + Math.random().toString(36).substring(2);
  },
  
  /**
   * Show a toast notification
   * @param {string} message - The message to display
   * @param {number} duration - Duration in milliseconds to show the toast
   */
  showToast: (message, duration = 3000) => {
    // Remove any existing toasts
    const existingToast = document.querySelector('.toast');
    if (existingToast) {
      existingToast.remove();
    }
    
    // Create and show the toast
    const toast = document.createElement('div');
    toast.className = 'toast';
    toast.textContent = message;
    document.body.appendChild(toast);
    
    // Trigger animation to show the toast
    setTimeout(() => {
      toast.classList.add('show');
    }, 10);
    
    // Remove the toast after the specified duration
    setTimeout(() => {
      toast.classList.remove('show');
      setTimeout(() => {
        toast.remove();
      }, 300);
    }, duration);
  },
  
  /**
   * Show a confirmation dialog
   * @param {string} message - The confirmation message
   * @returns {Promise<boolean>} A promise that resolves to true if confirmed, false otherwise
   */
  confirm: (message) => {
    return new Promise((resolve) => {
      const result = window.confirm(message);
      resolve(result);
    });
  },
  
  /**
   * Format a date object as a readable string
   * @param {Date} date - The date to format
   * @returns {string} Formatted date string
   */
  formatDate: (date) => {
    return new Date(date).toLocaleString(undefined, {
      year: 'numeric',
      month: 'short',
      day: 'numeric',
      hour: '2-digit',
      minute: '2-digit'
    });
  },
  
  /**
   * Truncate a string to a maximum length
   * @param {string} str - The string to truncate
   * @param {number} maxLength - Maximum length
   * @returns {string} Truncated string
   */
  truncateString: (str, maxLength) => {
    if (str.length <= maxLength) return str;
    return str.substring(0, maxLength) + '...';
  },
  
  /**
   * Debounce function to limit how often a function can be called
   * @param {Function} func - The function to debounce
   * @param {number} wait - Wait time in milliseconds
   * @returns {Function} Debounced function
   */
  debounce: (func, wait) => {
    let timeout;
    return function executedFunction(...args) {
      const later = () => {
        clearTimeout(timeout);
        func(...args);
      };
      clearTimeout(timeout);
      timeout = setTimeout(later, wait);
    };
  },
  
  /**
   * Check if the device is in dark mode
   * @returns {boolean} True if the device prefers dark mode
   */
  prefersDarkMode: () => {
    return window.matchMedia && window.matchMedia('(prefers-color-scheme: dark)').matches;
  }
};