/**
 * Handles note management functionality
 */
const Notes = {
  notesList: null,
  
  /**
   * Initialize the notes manager
   */
  init: () => {
    Notes.notesList = document.getElementById('notesList');
    
    // Set up event listeners
    document.getElementById('newNoteButton').addEventListener('click', Notes.createNewNote);
    
    // Populate the notes list
    Notes.populateNotesList();
  },
  
  /**
   * Populate the notes list with saved notes
   */
  populateNotesList: () => {
    // Clear the current list
    Notes.notesList.innerHTML = '';
    
    // Get all notes
    const notes = Storage.getAllNotes();
    const activeNoteId = Storage.getActiveNoteId();
    
    if (notes.length === 0) {
      const emptyMessage = document.createElement('div');
      emptyMessage.className = 'empty-notes';
      emptyMessage.textContent = 'No notes yet. Create one to get started!';
      Notes.notesList.appendChild(emptyMessage);
      return;
    }
    
    // Sort notes by last modified date (newest first)
    notes.sort((a, b) => new Date(b.lastModified) - new Date(a.lastModified));
    
    // Create list items for each note
    notes.forEach(note => {
      const noteItem = document.createElement('div');
      noteItem.className = 'note-item';
      if (note.id === activeNoteId) {
        noteItem.classList.add('active');
      }
      noteItem.dataset.id = note.id;
      
      // Add password indicator if the note is protected
      const isProtected = note.isProtected ? ' 🔒' : '';
      
      // Create item content
      noteItem.innerHTML = `
        <div class="note-title">${note.title || 'Untitled'}${isProtected}</div>
        <div class="note-actions">
          <button class="icon-button rename-note" title="Rename">
            <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M12 20h9"></path><path d="M16.5 3.5a2.121 2.121 0 0 1 3 3L7 19l-4 1 1-4L16.5 3.5z"></path></svg>
          </button>
          <button class="icon-button delete-note" title="Delete">
            <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M3 6h18"></path><path d="M19 6v14c0 1-1 2-2 2H7c-1 0-2-1-2-2V6"></path><path d="M8 6V4c0-1 1-2 2-2h4c1 0 2 1 2 2v2"></path></svg>
          </button>
        </div>
      `;
      
      // Add event listener for loading the note
      noteItem.addEventListener('click', (e) => {
        // Don't trigger if clicking on buttons
        if (e.target.closest('.note-actions')) return;
        
        Notes.loadNote(note.id);
      });
      
      // Add event listeners for note actions
      noteItem.querySelector('.rename-note').addEventListener('click', () => {
        Notes.renameNote(note.id);
      });
      
      noteItem.querySelector('.delete-note').addEventListener('click', () => {
        Notes.deleteNote(note.id);
      });
      
      Notes.notesList.appendChild(noteItem);
    });
  },
  
  /**
   * Create a new note
   */
  createNewNote: () => {
    // Create a new note object
    const newNote = {
      id: Utils.generateId(),
      title: 'Untitled',
      content: '',
      created: new Date().toISOString(),
      lastModified: new Date().toISOString(),
      isProtected: false
    };
    
    // Save to storage
    Storage.saveNote(newNote);
    
    // Update the UI
    Notes.populateNotesList();
    Editor.setCurrentNote(newNote);
    
    // Close the notes sidebar
    UI.closeSidebar('notesSidebar');
    
    Utils.showToast('New note created');
  },
  
  /**
   * Load a note by ID
   * @param {string} id - The note ID to load
   */
  loadNote: (id) => {
    const note = Storage.getNoteById(id);
    if (!note) return;
    
    // If the note is password protected, verify access
    if (note.isProtected) {
      Security.promptForPassword(note, (success) => {
        if (success) {
          Editor.setCurrentNote(note);
          Storage.setActiveNoteId(id);
          Notes.populateNotesList();
          UI.closeSidebar('notesSidebar');
        }
      });
    } else {
      // Note is not protected, load it directly
      Editor.setCurrentNote(note);
      Storage.setActiveNoteId(id);
      Notes.populateNotesList();
      UI.closeSidebar('notesSidebar');
    }
  },
  
  /**
   * Delete a note by ID
   * @param {string} id - The note ID to delete
   */
  deleteNote: async (id) => {
    const note = Storage.getNoteById(id);
    if (!note) return;
    
    const confirmMessage = `Are you sure you want to delete "${note.title || 'Untitled'}"? This cannot be undone.`;
    const confirmed = await Utils.confirm(confirmMessage);
    
    if (confirmed) {
      const deleted = Storage.deleteNote(id);
      
      if (deleted) {
        // If deleted successfully
        Notes.populateNotesList();
        
        // If this was the active note, load another one or create a new one
        if (Editor.getCurrentNote()?.id === id) {
          const notes = Storage.getAllNotes();
          if (notes.length > 0) {
            Notes.loadNote(notes[0].id);
          } else {
            Notes.createNewNote();
          }
        }
        
        Utils.showToast('Note deleted');
      }
    }
  },
  
  /**
   * Rename a note by ID
   * @param {string} id - The note ID to rename
   */
  renameNote: (id) => {
    const note = Storage.getNoteById(id);
    if (!note) return;
    
    const newTitle = prompt('Enter a new title:', note.title);
    if (newTitle !== null && newTitle.trim() !== '') {
      note.title = newTitle.trim();
      note.lastModified = new Date().toISOString();
      
      // Save the updated note
      Storage.saveNote(note);
      
      // Update the UI
      Notes.populateNotesList();
      
      // If this is the current note, update the title field
      if (Editor.getCurrentNote()?.id === id) {
        document.getElementById('noteTitle').value = note.title;
      }
      
      Utils.showToast('Note renamed');
    }
  },
  
  /**
   * Update a note in the list without refreshing the entire list
   * @param {Object} note - The note object to update
   */
  updateNoteInList: (note) => {
    if (!note) return;
    
    const noteItem = Notes.notesList.querySelector(`[data-id="${note.id}"] .note-title`);
    if (noteItem) {
      // Preserve password indicator if present
      const isProtected = note.isProtected ? ' 🔒' : '';
      noteItem.textContent = `${note.title || 'Untitled'}${isProtected}`;
    }
  }
};