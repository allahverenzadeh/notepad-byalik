/**
 * Handles UI interactions
 */
const UI = {
  /**
   * Initialize UI components
   */
  init: () => {
    // Initialize theme
    UI.initTheme();
    
    // Set up event listeners for sidebars
    document.getElementById('toggleNotes').addEventListener('click', () => {
      UI.toggleSidebar('notesSidebar');
    });
    
    document.getElementById('closeNotes').addEventListener('click', () => {
      UI.closeSidebar('notesSidebar');
    });
    
    document.getElementById('toggleSettings').addEventListener('click', () => {
      UI.toggleSidebar('settingsSidebar');
    });
    
    document.getElementById('closeSettings').addEventListener('click', () => {
      UI.closeSidebar('settingsSidebar');
    });
    
    // Set up theme toggle
    document.getElementById('toggleTheme').addEventListener('click', UI.toggleTheme);
    
    // Set up overlay click to close sidebars
    document.getElementById('overlay').addEventListener('click', () => {
      UI.closeAllSidebars();
      UI.closeAllModals();
    });
    
    // Set up settings event listeners
    document.getElementById('fontFamily').addEventListener('change', UI.updateSettings);
    document.getElementById('fontSize').addEventListener('change', UI.updateSettings);
    document.getElementById('fontColor').addEventListener('change', UI.updateSettings);
    document.getElementById('autoSave').addEventListener('change', UI.updateSettings);
    
    // Initialize settings values from storage
    UI.initSettingsUI();
  },
  
  /**
   * Initialize theme based on saved preference
   */
  initTheme: () => {
    const theme = Storage.getTheme();
    document.body.className = `${theme}-theme`;
  },
  
  /**
   * Toggle between light and dark themes
   */
  toggleTheme: () => {
    const currentTheme = document.body.classList.contains('dark-theme') ? 'dark' : 'light';
    const newTheme = currentTheme === 'dark' ? 'light' : 'dark';
    
    document.body.className = `${newTheme}-theme`;
    Storage.saveTheme(newTheme);
    
    Utils.showToast(`${newTheme.charAt(0).toUpperCase() + newTheme.slice(1)} theme applied`);
  },
  
  /**
   * Initialize settings UI values
   */
  initSettingsUI: () => {
    const settings = Storage.getSettings();
    
    // Set font family select
    const fontFamilySelect = document.getElementById('fontFamily');
    for (let i = 0; i < fontFamilySelect.options.length; i++) {
      if (fontFamilySelect.options[i].value === settings.fontFamily) {
        fontFamilySelect.selectedIndex = i;
        break;
      }
    }
    
    // Set font size select
    const fontSizeSelect = document.getElementById('fontSize');
    for (let i = 0; i < fontSizeSelect.options.length; i++) {
      if (fontSizeSelect.options[i].value === settings.fontSize) {
        fontSizeSelect.selectedIndex = i;
        break;
      }
    }
    
    // Set font color
    document.getElementById('fontColor').value = settings.fontColor;
    
    // Set auto-save interval
    const autoSaveSelect = document.getElementById('autoSave');
    for (let i = 0; i < autoSaveSelect.options.length; i++) {
      if (parseInt(autoSaveSelect.options[i].value) === settings.autoSave) {
        autoSaveSelect.selectedIndex = i;
        break;
      }
    }
  },
  
  /**
   * Update settings when changed
   */
  updateSettings: () => {
    const settings = {
      fontFamily: document.getElementById('fontFamily').value,
      fontSize: document.getElementById('fontSize').value,
      fontColor: document.getElementById('fontColor').value,
      autoSave: parseInt(document.getElementById('autoSave').value)
    };
    
    // Save settings
    Storage.saveSettings(settings);
    
    // Apply settings to editor
    Editor.applySettings();
    
    // Reconfigure auto-save
    Editor.setupAutoSave();
    
    Utils.showToast('Settings updated');
  },
  
  /**
   * Toggle a sidebar
   * @param {string} id - The ID of the sidebar to toggle
   */
  toggleSidebar: (id) => {
    const sidebar = document.getElementById(id);
    const isOpen = sidebar.classList.contains('open');
    
    // Close all sidebars first
    UI.closeAllSidebars();
    
    // If the sidebar wasn't open, open it now
    if (!isOpen) {
      sidebar.classList.add('open');
      document.getElementById('overlay').classList.add('active');
    }
  },
  
  /**
   * Close a specific sidebar
   * @param {string} id - The ID of the sidebar to close
   */
  closeSidebar: (id) => {
    const sidebar = document.getElementById(id);
    sidebar.classList.remove('open');
    
    // If no sidebars are open, hide the overlay
    const anySidebarOpen = document.querySelector('.sidebar.open');
    if (!anySidebarOpen) {
      document.getElementById('overlay').classList.remove('active');
    }
  },
  
  /**
   * Close all open sidebars
   */
  closeAllSidebars: () => {
    const sidebars = document.querySelectorAll('.sidebar');
    sidebars.forEach(sidebar => {
      sidebar.classList.remove('open');
    });
    
    document.getElementById('overlay').classList.remove('active');
  },
  
  /**
   * Open a modal dialog
   * @param {string} id - The ID of the modal to open
   */
  openModal: (id) => {
    const modal = document.getElementById(id);
    modal.classList.add('active');
    document.getElementById('overlay').classList.add('active');
  },
  
  /**
   * Close a modal dialog
   * @param {string} id - The ID of the modal to close
   */
  closeModal: (id) => {
    const modal = document.getElementById(id);
    modal.classList.remove('active');
    
    // If no modals or sidebars are open, hide the overlay
    const anyModalOpen = document.querySelector('.modal.active');
    const anySidebarOpen = document.querySelector('.sidebar.open');
    if (!anyModalOpen && !anySidebarOpen) {
      document.getElementById('overlay').classList.remove('active');
    }
  },
  
  /**
   * Close all open modals
   */
  closeAllModals: () => {
    const modals = document.querySelectorAll('.modal');
    modals.forEach(modal => {
      modal.classList.remove('active');
    });
  },
  
  /**
   * Show save status indicator
   * @param {string} message - Status message to display
   */
  showSaveStatus: (message) => {
    const saveStatus = document.getElementById('saveStatus');
    saveStatus.textContent = message;
    saveStatus.classList.add('visible');
    
    // Hide after 2 seconds
    setTimeout(() => {
      saveStatus.classList.remove('visible');
    }, 2000);
  }
};