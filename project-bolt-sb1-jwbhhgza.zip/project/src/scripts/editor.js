/**
 * Handles editor functionality for the Notepad application
 */
const Editor = {
  editor: null,
  titleInput: null,
  currentNote: null,
  undoStack: [],
  redoStack: [],
  autoSaveInterval: null,
  lastSavedContent: '',
  
  /**
   * Initialize the editor
   */
  init: () => {
    // Get DOM elements
    Editor.editor = document.getElementById('editor');
    Editor.titleInput = document.getElementById('noteTitle');
    
    // Set up event listeners
    Editor.editor.addEventListener('input', Editor.handleInput);
    Editor.titleInput.addEventListener('input', Editor.handleTitleChange);
    
    document.getElementById('saveButton').addEventListener('click', Editor.saveCurrentNote);
    document.getElementById('clearButton').addEventListener('click', Editor.clearEditor);
    document.getElementById('undoButton').addEventListener('click', Editor.undo);
    document.getElementById('redoButton').addEventListener('click', Editor.redo);
    
    // Apply saved settings
    Editor.applySettings();
    
    // Setup auto-save
    Editor.setupAutoSave();
  },
  
  /**
   * Apply editor settings from Storage
   */
  applySettings: () => {
    const settings = Storage.getSettings();
    
    Editor.editor.style.fontFamily = settings.fontFamily;
    Editor.editor.style.fontSize = settings.fontSize;
    Editor.editor.style.color = settings.fontColor;
  },
  
  /**
   * Setup auto-save functionality
   */
  setupAutoSave: () => {
    // Clear any existing interval
    if (Editor.autoSaveInterval) {
      clearInterval(Editor.autoSaveInterval);
    }
    
    const settings = Storage.getSettings();
    const autoSaveSeconds = parseInt(settings.autoSave);
    
    // If auto-save is enabled, set up the interval
    if (autoSaveSeconds > 0) {
      Editor.autoSaveInterval = setInterval(() => {
        const currentContent = Editor.editor.value;
        
        // Only save if content has changed since last save
        if (currentContent !== Editor.lastSavedContent) {
          Editor.saveCurrentNote(true); // silent save
        }
      }, autoSaveSeconds * 1000);
    }
  },
  
  /**
   * Handle input events in the editor
   */
  handleInput: () => {
    // Update text counters
    Counter.updateCounts();
    
    // Save current state for undo
    const currentContent = Editor.editor.value;
    if (currentContent !== Editor.lastSavedContent) {
      // Only add to undoStack if different from the last entry
      if (Editor.undoStack.length === 0 || Editor.undoStack[Editor.undoStack.length - 1] !== currentContent) {
        Editor.undoStack.push(currentContent);
        // Limit stack size to prevent memory issues
        if (Editor.undoStack.length > 50) {
          Editor.undoStack.shift();
        }
        // Clear redo stack on new input
        Editor.redoStack = [];
      }
    }
  },
  
  /**
   * Handle title changes
   */
  handleTitleChange: () => {
    if (Editor.currentNote) {
      Editor.currentNote.title = Editor.titleInput.value;
      // Update the note in the list
      Notes.updateNoteInList(Editor.currentNote);
    }
  },
  
  /**
   * Set the current note for editing
   * @param {Object} note - The note object
   */
  setCurrentNote: (note) => {
    Editor.currentNote = note;
    Editor.titleInput.value = note.title || '';
    Editor.editor.value = note.content || '';
    Editor.lastSavedContent = note.content || '';
    
    // Reset undo/redo stacks
    Editor.undoStack = [];
    Editor.redoStack = [];
    
    // Update counters
    Counter.updateCounts();
  },
  
  /**
   * Save the current note
   * @param {boolean} silent - Whether to show feedback
   */
  saveCurrentNote: (silent = false) => {
    if (!Editor.currentNote) return;
    
    // Update the note object
    Editor.currentNote.content = Editor.editor.value;
    Editor.currentNote.title = Editor.titleInput.value;
    Editor.currentNote.lastModified = new Date().toISOString();
    
    // Save to storage
    Storage.saveNote(Editor.currentNote);
    Editor.lastSavedContent = Editor.currentNote.content;
    
    // Update the UI
    if (!silent) {
      UI.showSaveStatus('Saved');
    }
  },
  
  /**
   * Clear the editor after confirmation
   */
  clearEditor: async () => {
    const confirmed = await Utils.confirm('Are you sure you want to clear the editor? This cannot be undone.');
    if (confirmed) {
      Editor.editor.value = '';
      Editor.undoStack = [];
      Editor.redoStack = [];
      Counter.updateCounts();
      
      // Save the cleared state
      if (Editor.currentNote) {
        Editor.currentNote.content = '';
        Storage.saveNote(Editor.currentNote);
        Editor.lastSavedContent = '';
      }
      
      Utils.showToast('Editor cleared');
    }
  },
  
  /**
   * Undo the last edit
   */
  undo: () => {
    if (Editor.undoStack.length <= 1) return;
    
    // Save current state to redo stack
    const currentContent = Editor.editor.value;
    Editor.redoStack.push(currentContent);
    
    // Remove current state from undo stack
    Editor.undoStack.pop();
    
    // Apply previous state
    const previousContent = Editor.undoStack[Editor.undoStack.length - 1];
    Editor.editor.value = previousContent;
    
    // Update counters
    Counter.updateCounts();
  },
  
  /**
   * Redo an undone edit
   */
  redo: () => {
    if (Editor.redoStack.length === 0) return;
    
    // Get state from redo stack
    const nextContent = Editor.redoStack.pop();
    
    // Add to undo stack
    Editor.undoStack.push(nextContent);
    
    // Apply the state
    Editor.editor.value = nextContent;
    
    // Update counters
    Counter.updateCounts();
  },
  
  /**
   * Get the current note
   * @returns {Object} The current note object
   */
  getCurrentNote: () => {
    return Editor.currentNote;
  }
};