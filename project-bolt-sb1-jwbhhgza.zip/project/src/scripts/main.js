/**
 * Main entry point for the Notepad application
 */
document.addEventListener('DOMContentLoaded', () => {
  // Initialize UI components
  UI.init();
  
  // Initialize the editor
  Editor.init();
  
  // Initialize the notes manager
  Notes.init();
  
  // Initialize counter
  Counter.init();
  
  // Initialize security features
  Security.init();
  
  // Initialize export functionality
  Export.init();
  
  // Load the current note or create a default one
  const activeNoteId = Storage.getActiveNoteId();
  if (activeNoteId) {
    Notes.loadNote(activeNoteId);
  } else {
    Notes.createNewNote();
  }
});

// Listen for unload events to save the current state
window.addEventListener('beforeunload', () => {
  Editor.saveCurrentNote();
});